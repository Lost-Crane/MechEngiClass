local function getGrenadeDamage(skill, attacker, isFromItem, ...)
    if isFromItem and skill.Name == "WHATEVER_GRENADE_SKILL" and Whatever(attacker) then
        local damageList, deathType = Game.Math.GetSkillDamage(skill, attacker, isFromItem, ...)
        damageList:Multiply(1.5)
        return damageList, deathType
    end
end

Ext.RegisterListener("GetSkillDamage", getGrenadeDamage)