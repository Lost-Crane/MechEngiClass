local grenadeDescriptionParam = function (skill, character, isFromItem, param)
    if skill.Name == "WHATEVER_GRENADE_SKILL" and param == "Damage" then
        return "replace tooltip here"
    end
end

Ext.RegisterListener("SkillGetDescriptionParam", grenadeDescriptionParam)