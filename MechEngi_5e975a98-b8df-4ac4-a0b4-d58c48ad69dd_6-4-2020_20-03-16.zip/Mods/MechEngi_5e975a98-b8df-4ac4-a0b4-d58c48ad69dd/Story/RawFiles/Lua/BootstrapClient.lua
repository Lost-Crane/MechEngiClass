-- Credit: LaughingLeader <3
local DamageTypeHandles = {
    None = {Handle="h8a070775gc251g4f34g9086gb1772f7e2cff",Content="pure damage", Color="#CD1F1F"},
    Physical = {Handle="h40782d69gbfaeg40cegbe3cg370ef44e3980",Content="physical damage", Color="#a8a8a8"},
    Piercing = {Handle="hd05581a1g83a7g4d95gb59fgfa5ef68f5c90",Content="piercing damage", Color="#CD1F1F"},
    Corrosive = {Handle="h161d5479g06d6g408egade2g37a203e3361f",Content="corrosive damage", Color="#797980"},
    Magic = {Handle="hdb4307b4g1a6fg4c05g9602g6a4a6e7a29d9",Content="magic damage", Color="#7F00FF"},
    -- Special LeaderLib handle
    Chaos = {Handle="h2bc14afag7627g4db8gaaa6g19c26b9820d5",Content="chaos damage", Color="#CD1F1F"},
    Air = {Handle="hdd80e44fg9585g48b8ga34dgab20dc18f077",Content="air damage", Color="#7D71D9"},
    Earth = {Handle="h68b77a37g9c43g4436gb360gd651af08d7bb",Content="earth damage", Color="#7f3d00"},
    Fire = {Handle="hc4d062edgd8e6g4048gaa44g160fe3c7b018",Content="fire damage", Color="#FE6E27"},
    Poison = {Handle="ha77d36b3ge969g4461g9b30gfff624024b18",Content="poison damage", Color="#65C900"},
    Shadow = {Handle="h256557fbg1d49g45d9g8690gb86b39d2a135",Content="shadow damage", Color="#797980"},
    Water = {Handle="h8cdcfeedg357eg4877ga69egc05dbe9c68a4",Content="water damage", Color="#4197E2"},
}

-- Credit: LaughingLeader <3
local function GetDamageText(damageType, damageValue)
    local entry = DamageTypeHandles[damageType]
    if entry ~= nil then
        local name = Ext.GetTranslatedString(entry.Handle, entry.Content)
        return string.format("<font color='%s'>%s %s</font>", entry.Color, damageValue, name)
    else
        Ext.PrintError("No damage name/color entry for type " .. tostring(damageType))
    end
    return ""
end

local function GetGrenadeBoostVal(character, skill)
    local damageMultiplier = skill['Damage Multiplier'] * 0.01
    local baseDamage = Game.Math.CalculateBaseDamage(skill.Damage, character, 0, character.Level) * damageMultiplier
    local damageRange = skill['Damage Range'] * baseDamage * 0.005
    local damageType = skill.DamageType
    local damageTypeBoost = 1.0 + Game.Math.GetDamageBoostByType(character, damageType)
    local warriorMultiplier = 1 + (character.WarriorLore * 0.1)
    local damageBoost = 1.0 + (character.DamageBoost / 100.0)

    local floor = math.floor(math.floor(math.floor((baseDamage - damageRange) * damageBoost) * damageTypeBoost) * warriorMultiplier)
    local ceil = math.ceil(math.ceil(math.ceil((baseDamage + damageRange) * damageBoost) * damageTypeBoost) * warriorMultiplier)

    local rangeText = floor.."-"..ceil
    local damageRangeParam = GetDamageText(skill.DamageType, rangeText)

    return damageRangeParam
end

local function grenadeDescriptionParam (skill, character, isFromItem, param)
    if string.find(skill.Name, "_Grenade_") and param == "Damage" then
        local damageRange = Game.Math.GetSkillDamageRange(character, skill)
        if damageRange ~= nil then
            local damageTexts = {}
            local totalDamageTypes = 0
            for damageType,damage in pairs(damageRange) do
                local min = damage[1]
                local max = damage[2]
		min = min * character.WarriorLore * 0.1
		max = max * character.WarriorLore * 0.1
                if min > 0 or max > 0 then
                    if max == min then
                        table.insert(damageTexts, Mods.LeaderLib.Game.GetDamageText(damageType, string.format("%i", max)))
                    else
                        table.insert(damageTexts, Mods.LeaderLib.Game.GetDamageText(damageType, string.format("%i-%i", min, max)))
                    end
                end
                totalDamageTypes = totalDamageTypes + 1
            end
            if totalDamageTypes > 0 then
                if totalDamageTypes > 1 then
                    return Mods.LeaderLib.Common.StringJoin(", ", damageTexts)
                else
                    return damageTexts[1]
                end
            end
        end
    end
end

Ext.RegisterListener("SkillGetDescriptionParam", grenadeDescriptionParam)